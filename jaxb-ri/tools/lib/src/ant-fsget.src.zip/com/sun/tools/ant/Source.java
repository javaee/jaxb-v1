package com.sun.tools.ant;

import org.apache.tools.ant.Project;

import java.net.URL;

/**
 * @author Kohsuke Kawaguchi
 */
public class Source {
    private URL url;
    private String _if;
    private String unless;

    public URL getUrl() {
        return url;
    }

    public void setUrl(URL url) {
        this.url = url;
    }

    public void setIf(String _if) {
        this._if = _if;
    }

    public void setUnless(String unless) {
        this.unless = unless;
    }

    /**
     * Returns true if this source location is active.
     */
    public boolean isActive( Project p ) {
        if(_if!=null && p.getProperty(_if)==null )
            return false;

        if(unless!=null && p.getProperty(unless)!=null)
            return false;

        return true;
    }
}
